package FoSProject;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

public class SpecialTiles {
	
	private Board board;
	
	public SpecialTiles(Board board) {
		this.board = board;
	}
	
	public int rndGridNum() {
		return ThreadLocalRandom.current().nextInt(0, 15);
	}		
	
	public void generateSpecialTilesInit() {
		int anzahlTreasure = 5; 
		int anzahlEnergie = 4; 
		/*Key: Integer (ID), Value: String (Name)
		final Map<Integer, String> tileNames = Map.of(
		    1, "Treasure",
		    2, "Energie"
		);*/
		
		for (int i = 0; i < anzahlTreasure; i++) { // TIDI; deb scgeuss aendern: durch 2d arrays oder idealerweise per eigener klasse:zB TileINfo(name, id, amountgenerated, effect, etc.)
			generateSpecialTile(1);
		}
		for (int i = 0; i < anzahlEnergie; i++) {
			generateSpecialTile(2);
		}		
	}	
	public void generateSpecialTile(int tileID) {
		int rndX, rndY;
		while (true) {
			rndX = rndGridNum();
			rndY = rndGridNum();
			if ((board.spielfeldMatrix[rndY][rndX].getText() == null && board.spielfeldMatrix[rndY][rndX].getIcon() == null) || ((board.spielfeldMatrix[rndY][rndX].getText() == "" && board.spielfeldMatrix[rndY][rndX].getIcon() == null))){
				switch (tileID) {
					case 1: 
						board.spielfeldMatrix[rndY][rndX].setText("Treasure"); 
						break;
					case 2: 
						board.spielfeldMatrix[rndY][rndX].setText("Energie"); 
						break;
					default: 
						System.out.println("ungueltige tile ID (generierung)"); 
						break;
				} 
				return; 
			}
		}
	}
	
	public void collectTreasure() {
		
	}
	
	public void collectEnergie() {
		
	}
}
